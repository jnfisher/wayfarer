MegaMUD v2.0 Alpha (02/23/2026)
------------------------------------------
- Registration removed
- Added option to only stash coin up to a chosen coin type
- Added support for eyes, face, worn, "everywhere", and second wrist slot
- Added support for "[PARADIGM]:" realm entry prompt
- Added support for detecting "None" (vs NONE!) exit type
- Added search/filter box to Goto Location list
- Can now press escape to cancel the goto list
- Disabled conversation history mouse scrolling and auto-submit
- Filename will now be shown before the app name in the titlebar/taskbar
- Moved main megamud.ini to be next to megamud.exe (instead of c:\windows)
- Added default BBS sign-on prompts and replys for fresh installs
- Doubled the number of internal loops performed to find the best path
- Back-scroll buffer limit increased to 1048576 bytes (from 32000)
- Added Shift+F3 shortcut for 'find new' on back-scroll window
- Expanded HP/MP on party windows to 5 digits
- Fixed sizing of party window on some displays and operating systems
- Increased exp calculation up to level 500
- Added "millions per hour" experience notation (### m/hr)
- Collected copper total now supports over 4.2B (limit UINT > ULL)
- Better handling of pre/post cmds, message responses, etc that equip items
- Fix for periods becoming part of player/monster names while exiting the realm
- Fix for hiding and pausing at the first room one can hide after pathing somewhere
- Fixed rollover of time on the time analysis window
- Fixes for recursive receive/strcpy overloads/crashes **
- Fix crash/halt when picking up coin near encumbrance limits **
- Dial-up/Modem/ZModem functionality removed
- Known Issue: Not compatible with Windows XP (may or may not fix)

** These items have had additional trace information added to logs for further debugging. Please report any observations in your trace files.

Please submit error reports and feature requests at https://www.mudinfo.net/viewforum.php?f=68

Included paths (if included) are already loaded with Winterawks 2.0 paths from mudinfo.net.

Thank you to Merlin for creating MegaMUD. Brought to you by Apathy and Syntax.
